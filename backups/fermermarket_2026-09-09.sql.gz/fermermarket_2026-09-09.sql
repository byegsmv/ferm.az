--
-- PostgreSQL database dump
--

\restrict 8pRtIyNtXgSA72dnvV0ko9DefVYnYIE6KoRRSOdebVIhEXXj8X8GDGlHi91N8vB

-- Dumped from database version 18.6 (2078fcb)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: neon_auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA neon_auth;


--
-- Name: CampaignStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'ACTIVE',
    'PAUSED',
    'EXPIRED'
);


--
-- Name: CampaignType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignType" AS ENUM (
    'HOMEPAGE_BANNER',
    'CATEGORY_BANNER',
    'STORE_PROMOTION',
    'FLASH_SALE',
    'DAILY_DEAL',
    'SPONSORED_PRODUCT',
    'REGIONAL'
);


--
-- Name: ListingTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ListingTier" AS ENUM (
    'STANDARD',
    'FEATURED',
    'PREMIUM',
    'VIP'
);


--
-- Name: Locale; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Locale" AS ENUM (
    'AZ',
    'EN',
    'RU'
);


--
-- Name: ModuleKey; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ModuleKey" AS ENUM (
    'WALLET',
    'BLOG',
    'BUNDLES',
    'CORPORATE_LISTINGS',
    'AI_AGRONOM',
    'ANALYTICS',
    'CAMPAIGNS',
    'BULK_CSV',
    'DELIVERY',
    'LEADERBOARD',
    'CATEGORIES_SLIDER',
    'HERO_SECTION',
    'PROMO_BANNER',
    'PRODUCTS_GRID',
    'BLOG_SECTION',
    'TESTIMONIALS',
    'NEWSLETTER_SIGNUP',
    'WEATHER_WIDGET',
    'AGRONOMIST_AI',
    'COMPARISON_TOOL',
    'FAVORITES',
    'DIRECT_MESSAGING',
    'WALLET_SYSTEM',
    'STORE_RATINGS'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'PROCESSING',
    'SHIPPED',
    'DELIVERED',
    'CANCELLED',
    'REFUNDED'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'SUCCEEDED',
    'FAILED',
    'REFUNDED'
);


--
-- Name: ProcurementRequestStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProcurementRequestStatus" AS ENUM (
    'NEW',
    'IN_REVIEW',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: ProductRegistrationRequestStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductRegistrationRequestStatus" AS ENUM (
    'NEW',
    'IN_REVIEW',
    'APPROVED',
    'REJECTED'
);


--
-- Name: ProductStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductStatus" AS ENUM (
    'DRAFT',
    'PENDING_REVIEW',
    'ACTIVE',
    'SOLD',
    'EXPIRED',
    'REJECTED'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'MODERATOR',
    'FARMER',
    'STORE',
    'AGRONOMIST',
    'BUYER',
    'DELIVERY_PARTNER'
);


--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'PENDING_VERIFICATION',
    'SUSPENDED',
    'BANNED'
);


--
-- Name: WalletTxStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WalletTxStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'REJECTED'
);


--
-- Name: WalletTxType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WalletTxType" AS ENUM (
    'EARNING',
    'WITHDRAWAL',
    'REFUND',
    'ADJUSTMENT',
    'COMMISSION_DEDUCTION',
    'COIN_GIFT',
    'COIN_SPEND',
    'PURCHASE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" uuid NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp with time zone,
    "refreshTokenExpiresAt" timestamp with time zone,
    scope text,
    password text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: invitation; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.invitation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    email text NOT NULL,
    role text,
    status text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "inviterId" uuid NOT NULL
);


--
-- Name: jwks; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.jwks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "publicKey" text NOT NULL,
    "privateKey" text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "expiresAt" timestamp with time zone
);


--
-- Name: member; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.member (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL
);


--
-- Name: organization; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.organization (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    logo text,
    "createdAt" timestamp with time zone NOT NULL,
    metadata text
);


--
-- Name: project_config; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.project_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    endpoint_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    trusted_origins jsonb NOT NULL,
    social_providers jsonb NOT NULL,
    email_provider jsonb,
    email_and_password jsonb,
    allow_localhost boolean NOT NULL,
    plugin_configs jsonb,
    webhook_config jsonb
);


--
-- Name: session; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" uuid NOT NULL,
    "impersonatedBy" text,
    "activeOrganizationId" text
);


--
-- Name: user; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth."user" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "emailVerified" boolean NOT NULL,
    image text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role text,
    banned boolean,
    "banReason" text,
    "banExpires" timestamp with time zone
);


--
-- Name: verification; Type: TABLE; Schema: neon_auth; Owner: -
--

CREATE TABLE neon_auth.verification (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AIAgroRule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AIAgroRule" (
    id text NOT NULL,
    "triggerDiseaseId" text,
    "triggerPestId" text,
    condition text,
    "recommendedProductIds" text[],
    priority integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: ActiveIngredient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ActiveIngredient" (
    id text NOT NULL,
    name text NOT NULL,
    "nameAz" text NOT NULL,
    cas text,
    "group" text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AdSlot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AdSlot" (
    id text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    mode text DEFAULT 'internal'::text NOT NULL,
    "campaignType" text,
    "externalCode" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AgroServiceRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgroServiceRequest" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "serviceType" text NOT NULL,
    "farmLocation" text,
    "cropType" text,
    area text,
    notes text,
    "contactPhone" text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    result text,
    "resultFileUrl" text,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AiSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiSettings" (
    id text NOT NULL,
    "modelName" text DEFAULT 'gpt-4'::text NOT NULL,
    "systemPrompt" text NOT NULL,
    temperature double precision DEFAULT 0.7 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    entity text NOT NULL,
    "entityId" text,
    metadata jsonb,
    "oldValues" jsonb,
    "newValues" jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: BlogPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlogPost" (
    id text NOT NULL,
    slug text NOT NULL,
    "titleAz" text NOT NULL,
    "titleEn" text,
    "titleRu" text,
    "contentAz" text NOT NULL,
    "contentEn" text,
    "contentRu" text,
    "coverUrl" text,
    category text,
    "authorId" text NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Brand; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Brand" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "logoUrl" text,
    country text,
    website text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Bundle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Bundle" (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "sellerId" text NOT NULL,
    "storeId" text,
    "discountType" text NOT NULL,
    "discountValue" numeric(10,2) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: BundleItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BundleItem" (
    id text NOT NULL,
    "bundleId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


--
-- Name: CalculatorSession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CalculatorSession" (
    id text NOT NULL,
    "userId" text,
    "productId" text,
    area double precision NOT NULL,
    "areaUnit" text NOT NULL,
    "useNorm" double precision NOT NULL,
    "waterNorm" double precision NOT NULL,
    applications integer NOT NULL,
    result jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Campaign" (
    id text NOT NULL,
    title text NOT NULL,
    type public."CampaignType" NOT NULL,
    status public."CampaignStatus" DEFAULT 'DRAFT'::public."CampaignStatus" NOT NULL,
    "bannerUrl" text,
    "targetUrl" text,
    "storeId" text,
    "categoryId" text,
    region text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    budget numeric(12,2),
    "costPerClick" numeric(8,4),
    impressions integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    conversions integer DEFAULT 0 NOT NULL,
    spend numeric(12,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    slug text NOT NULL,
    "nameAz" text NOT NULL,
    "nameEn" text,
    "nameRu" text,
    description text,
    icon text,
    "parentId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ClimateWarning; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ClimateWarning" (
    id text NOT NULL,
    region text NOT NULL,
    "warningType" text NOT NULL,
    severity text NOT NULL,
    message text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "isSmsSent" boolean DEFAULT false NOT NULL,
    "isPushSent" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ComparisonSession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ComparisonSession" (
    id text NOT NULL,
    "userId" text,
    "productIds" text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ContactMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ContactMessage" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    subject text,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Conversation" (
    id text NOT NULL,
    "buyerId" text NOT NULL,
    "sellerId" text NOT NULL,
    "productId" text,
    "lastMessageAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Coupon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Coupon" (
    id text NOT NULL,
    code text NOT NULL,
    "discountType" text NOT NULL,
    "discountValue" numeric(10,2) NOT NULL,
    "minOrderValue" numeric(10,2),
    "maxUses" integer,
    "usedCount" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "startsAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Crop; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Crop" (
    id text NOT NULL,
    name text NOT NULL,
    "nameAz" text NOT NULL,
    slug text NOT NULL,
    image text
);


--
-- Name: Disease; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Disease" (
    id text NOT NULL,
    name text NOT NULL,
    "nameAz" text NOT NULL,
    slug text NOT NULL,
    images text[],
    "affectedCrops" text[],
    symptoms text,
    causes text,
    prevention text,
    treatment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: DynamicBlock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DynamicBlock" (
    id text NOT NULL,
    page text DEFAULT 'home'::text NOT NULL,
    type text NOT NULL,
    props jsonb NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EscrowTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EscrowTransaction" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    amount numeric(12,2) NOT NULL,
    status text NOT NULL,
    "disputeReason" text,
    "resolvedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: FarmerProfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FarmerProfile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    region text,
    village text,
    "totalArea" double precision,
    crops text[],
    greenhouse double precision,
    garden double precision,
    "irrigationType" text,
    "soilAnalysis" jsonb,
    "previousProducts" text[],
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Favorite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Favorite" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "productId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: HomepageSlide; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HomepageSlide" (
    id text NOT NULL,
    tag text NOT NULL,
    title text NOT NULL,
    subtitle text NOT NULL,
    cta text DEFAULT 'Bax'::text NOT NULL,
    href text NOT NULL,
    bg text DEFAULT 'from-brand-700 to-brand-500'::text NOT NULL,
    emoji text DEFAULT '🌾'::text NOT NULL,
    "imageUrl" text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: IncomingEmail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."IncomingEmail" (
    id text NOT NULL,
    "fromEmail" text NOT NULL,
    "fromName" text,
    "toEmail" text NOT NULL,
    subject text NOT NULL,
    "bodyText" text,
    "bodyHtml" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "isStarred" boolean DEFAULT false NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "isReplied" boolean DEFAULT false NOT NULL,
    "replyBody" text,
    "replySubject" text,
    "replySentAt" timestamp(3) without time zone,
    attachments jsonb,
    "messageId" text,
    "inReplyTo" text,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Listing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Listing" (
    id text NOT NULL,
    "productId" text NOT NULL,
    tier public."ListingTier" DEFAULT 'STANDARD'::public."ListingTier" NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDate" timestamp(3) without time zone,
    "autoRenew" boolean DEFAULT false NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: LogisticsTariff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LogisticsTariff" (
    id text NOT NULL,
    "fromRegion" text NOT NULL,
    "toRegion" text NOT NULL,
    "basePrice" numeric(10,2) NOT NULL,
    "pricePerKg" numeric(10,2) NOT NULL,
    "estimatedDays" integer NOT NULL
);


--
-- Name: LoyaltyLevel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LoyaltyLevel" (
    id text NOT NULL,
    "levelName" text NOT NULL,
    "minPoints" integer NOT NULL,
    "discountPercent" double precision DEFAULT 0 NOT NULL,
    perks text[]
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "senderId" text NOT NULL,
    content text NOT NULL,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "buyerId" text NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    discount numeric(12,2) DEFAULT 0 NOT NULL,
    commission numeric(12,2) DEFAULT 0 NOT NULL,
    total numeric(12,2) NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    "couponId" text,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "shippingAddress" text,
    "shippingRegion" text,
    "shippingCity" text,
    "deliveryMethod" text DEFAULT 'STANDARD'::text NOT NULL,
    "deliveryCost" numeric(12,2) DEFAULT 0 NOT NULL,
    "deliveryPartnerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "sellerId" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" numeric(12,2) NOT NULL,
    "commissionRate" numeric(5,4) DEFAULT 0.05 NOT NULL
);


--
-- Name: PageLayout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PageLayout" (
    id text NOT NULL,
    "pageName" text NOT NULL,
    components jsonb NOT NULL,
    "themeColor" text DEFAULT 'green'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    provider text NOT NULL,
    "providerRef" text,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "rawResponse" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    action text NOT NULL,
    description text
);


--
-- Name: Pest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Pest" (
    id text NOT NULL,
    name text NOT NULL,
    "nameAz" text NOT NULL,
    slug text NOT NULL,
    images text[],
    "affectedCrops" text[],
    symptoms text,
    lifecycle text,
    prevention text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ProcurementRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProcurementRequest" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "productName" text NOT NULL,
    "categoryId" text,
    quantity integer NOT NULL,
    unit text NOT NULL,
    budget numeric(12,2),
    "deliveryLocation" text NOT NULL,
    description text,
    status public."ProcurementRequestStatus" DEFAULT 'NEW'::public."ProcurementRequestStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    slug text NOT NULL,
    "titleAz" text NOT NULL,
    "titleEn" text,
    "titleRu" text,
    "descriptionAz" text,
    "descriptionEn" text,
    "descriptionRu" text,
    price numeric(12,2) NOT NULL,
    "discountedPrice" numeric(12,2),
    currency text DEFAULT 'AZN'::text NOT NULL,
    stock integer DEFAULT 1 NOT NULL,
    status public."ProductStatus" DEFAULT 'PENDING_REVIEW'::public."ProductStatus" NOT NULL,
    "categoryId" text NOT NULL,
    "sellerId" text,
    "guestName" text,
    "guestPhone" text,
    "storeId" text,
    region text,
    city text,
    lat double precision,
    lng double precision,
    tags text[] DEFAULT ARRAY[]::text[],
    "isCorporate" boolean DEFAULT false NOT NULL,
    "minOrderQty" integer,
    "allowRetail" boolean DEFAULT true NOT NULL,
    unit text DEFAULT 'ədəd'::text NOT NULL,
    "allowInstallment" boolean DEFAULT false NOT NULL,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "phoneViews" integer DEFAULT 0 NOT NULL,
    attributes jsonb,
    "rejectionReason" text,
    "preparativeForm" text,
    "useNorm" text,
    "waterVolume" text,
    "waitingPeriod" integer,
    "maxApplications" integer,
    "mixingCompatibility" text,
    "safetyInfo" text,
    "storageInfo" text,
    certificate text,
    "labelPdfUrl" text,
    "instructionPdfUrl" text,
    "labelPdf" text,
    "instructionPdf" text,
    "videoUrl" text,
    barcode text,
    "productCode" text,
    packaging text,
    "wholesalePrice" numeric(12,2),
    "wholesaleMinQty" integer,
    manufacturer text,
    "brandId" text,
    "countryOfOrigin" text,
    "compareCount" integer DEFAULT 0 NOT NULL,
    "isOrganic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone
);


--
-- Name: ProductActiveIngredient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductActiveIngredient" (
    "productId" text NOT NULL,
    "activeIngredientId" text NOT NULL,
    concentration text
);


--
-- Name: ProductCrop; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductCrop" (
    "productId" text NOT NULL,
    "cropId" text NOT NULL
);


--
-- Name: ProductDisease; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductDisease" (
    "productId" text NOT NULL,
    "diseaseId" text NOT NULL
);


--
-- Name: ProductImage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductImage" (
    id text NOT NULL,
    "productId" text NOT NULL,
    url text NOT NULL,
    "altText" text,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


--
-- Name: ProductPest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductPest" (
    "productId" text NOT NULL,
    "pestId" text NOT NULL
);


--
-- Name: ProductRegistrationRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductRegistrationRequest" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "productName" text NOT NULL,
    "categoryId" text,
    description text,
    "sellerInfo" text,
    price numeric(12,2),
    images text[],
    documents text[],
    notes text,
    status public."ProductRegistrationRequestStatus" DEFAULT 'NEW'::public."ProductRegistrationRequestStatus" NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PushSubscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PushSubscription" (
    id text NOT NULL,
    "userId" text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


--
-- Name: Review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Review" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "authorId" text NOT NULL,
    rating integer NOT NULL,
    comment text,
    "isApproved" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    role public."UserRole" NOT NULL,
    "permissionId" text NOT NULL
);


--
-- Name: SalesPoint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SalesPoint" (
    id text NOT NULL,
    "storeId" text NOT NULL,
    region text NOT NULL,
    city text,
    address text NOT NULL,
    lat double precision,
    lng double precision,
    phone text,
    "workHours" text,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Setting" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SiteText; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SiteText" (
    id text NOT NULL,
    key text NOT NULL,
    "group" text DEFAULT 'general'::text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    "valueAz" text DEFAULT ''::text NOT NULL,
    "valueEn" text,
    "valueRu" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Store" (
    id text NOT NULL,
    "ownerId" text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    "logoUrl" text,
    "coverUrl" text,
    address text,
    lat double precision,
    lng double precision,
    whatsapp text,
    phone text,
    website text,
    "isVerified" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "installmentEnabled" boolean DEFAULT false NOT NULL,
    "installmentWhatsapp" text,
    email text,
    facebook text,
    instagram text,
    tiktok text,
    linkedin text,
    youtube text,
    telegram text,
    "workingHours" jsonb,
    "deliveryRegions" text[] DEFAULT ARRAY[]::text[],
    "taxInfo" text,
    "bankName" text,
    "bankAccount" text,
    iban text,
    "supportEmail" text,
    "supportPhone" text,
    "primaryColor" text DEFAULT '#16a34a'::text,
    "secondaryColor" text,
    "themeMode" text DEFAULT 'light'::text,
    "followerCount" integer DEFAULT 0 NOT NULL,
    "storeViewCount" integer DEFAULT 0 NOT NULL,
    "totalSales" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: StoreFollow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StoreFollow" (
    id text NOT NULL,
    "storeId" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: StoreSubscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StoreSubscription" (
    id text NOT NULL,
    "storeId" text NOT NULL,
    plan text NOT NULL,
    "planId" text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "renewsAt" timestamp(3) without time zone
);


--
-- Name: SubscriptionPlan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SubscriptionPlan" (
    id text NOT NULL,
    name text NOT NULL,
    price numeric(10,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    "durationDays" integer DEFAULT 30 NOT NULL,
    "maxListings" integer DEFAULT 10 NOT NULL,
    "freeVipListings" integer DEFAULT 0 NOT NULL,
    "customSubdomain" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: SystemText; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemText" (
    id text NOT NULL,
    key text NOT NULL,
    "valueAz" text NOT NULL,
    "valueEn" text,
    "valueRu" text,
    module text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: TieredPrice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TieredPrice" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "tierType" text NOT NULL,
    "minQuantity" integer DEFAULT 1 NOT NULL,
    price numeric(12,2) NOT NULL,
    "regionCode" text,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: Translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Translation" (
    id text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    field text NOT NULL,
    locale public."Locale" NOT NULL,
    value text NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text,
    phone text,
    username text,
    "passwordHash" text NOT NULL,
    "fullName" text NOT NULL,
    role public."UserRole" DEFAULT 'BUYER'::public."UserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'PENDING_VERIFICATION'::public."UserStatus" NOT NULL,
    locale public."Locale" DEFAULT 'AZ'::public."Locale" NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "phoneVerified" boolean DEFAULT false NOT NULL,
    "isBanned" boolean DEFAULT false NOT NULL,
    "avgRating" double precision DEFAULT 0 NOT NULL,
    "reviewCount" integer DEFAULT 0 NOT NULL,
    "deliveryRating" double precision DEFAULT 0 NOT NULL,
    "onTimeDeliveryRate" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "storeId" text
);


--
-- Name: UserModule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserModule" (
    id text NOT NULL,
    "userId" text NOT NULL,
    module public."ModuleKey" NOT NULL,
    "grantedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Wallet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Wallet" (
    id text NOT NULL,
    "userId" text NOT NULL,
    balance numeric(12,2) DEFAULT 0 NOT NULL,
    coins numeric(12,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WalletTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WalletTransaction" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    type public."WalletTxType" NOT NULL,
    status public."WalletTxStatus" DEFAULT 'COMPLETED'::public."WalletTxStatus" NOT NULL,
    amount numeric(12,2) NOT NULL,
    "orderId" text,
    description text,
    "loyaltyPointsEarned" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: account; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.account (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invitation; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.invitation (id, "organizationId", email, role, status, "expiresAt", "createdAt", "inviterId") FROM stdin;
\.


--
-- Data for Name: jwks; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.jwks (id, "publicKey", "privateKey", "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: member; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.member (id, "organizationId", "userId", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.organization (id, name, slug, logo, "createdAt", metadata) FROM stdin;
\.


--
-- Data for Name: project_config; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.project_config (id, name, endpoint_id, created_at, updated_at, trusted_origins, social_providers, email_provider, email_and_password, allow_localhost, plugin_configs, webhook_config) FROM stdin;
0ad95001-421a-4532-9e77-b05504100746	neon-alizarin-leaf	ep-rough-salad-b2j3zdyw	2026-09-09 20:08:32.524+00	2026-09-09 20:08:32.524+00	[{"domain": "https://fermermarket.az"}, {"domain": "https://www.fermermarket.az"}, {"domain": "https://ferm-az.vercel.app"}, {"domain": "https://ferm-az-byegsmv.vercel.app"}, {"domain": "https://ferm-az-git-main-byegsmv.vercel.app"}, {"domain": "https://ferm-j9yk0ke9p-byegsmv.vercel.app"}, {"domain": "https://ferm-j2z4o4maw-byegsmv.vercel.app"}, {"domain": "https://ferm-k4g01y3ie-byegsmv.vercel.app"}, {"domain": "https://ferm-rmdy6dlyq-byegsmv.vercel.app"}, {"domain": "https://ferm-50dcolvd1-byegsmv.vercel.app"}, {"domain": "https://ferm-170pypvrq-byegsmv.vercel.app"}, {"domain": "https://ferm-2ui4splyi-byegsmv.vercel.app"}, {"domain": "https://ferm-2my1jyb4c-byegsmv.vercel.app"}, {"domain": "https://ferm-jspc52xd2-byegsmv.vercel.app"}, {"domain": "https://ferm-az-git-claude-confident-bardeen-8wfxfp-byegsmv.vercel.app"}, {"domain": "https://ferm-2glalwccm-byegsmv.vercel.app"}, {"domain": "https://ferm-hsaggxdrt-byegsmv.vercel.app"}, {"domain": "https://ferm-o7zh3x48f-byegsmv.vercel.app"}, {"domain": "https://ferm-bhzyq7ifn-byegsmv.vercel.app"}, {"domain": "https://ferm-pk4k5mts6-byegsmv.vercel.app"}, {"domain": "https://ferm-glfseszry-byegsmv.vercel.app"}, {"domain": "https://ferm-43cn1jvll-byegsmv.vercel.app"}, {"domain": "https://ferm-a3qt5vmnp-byegsmv.vercel.app"}]	[{"id": "google", "isShared": true}]	{"type": "shared"}	{"enabled": true, "disableSignUp": false, "emailVerificationMethod": "otp", "requireEmailVerification": false, "autoSignInAfterVerification": true, "sendVerificationEmailOnSignIn": false, "sendVerificationEmailOnSignUp": false}	t	{"magicLink": {"config": {"expiresIn": 5, "disableSignUp": false}, "enabled": false}, "phoneNumber": {"config": {"otp_expires_in": 300}, "enabled": false}, "organization": {"config": {"creatorRole": "owner", "membershipLimit": 100, "organizationLimit": 10, "sendInvitationEmail": false}, "enabled": true}}	{"enabled": false, "enabledEvents": [], "timeoutSeconds": 5}
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.session (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId", "impersonatedBy", "activeOrganizationId") FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth."user" (id, name, email, "emailVerified", image, "createdAt", "updatedAt", role, banned, "banReason", "banExpires") FROM stdin;
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: neon_auth; Owner: -
--

COPY neon_auth.verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AIAgroRule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AIAgroRule" (id, "triggerDiseaseId", "triggerPestId", condition, "recommendedProductIds", priority, "isActive") FROM stdin;
\.


--
-- Data for Name: ActiveIngredient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ActiveIngredient" (id, name, "nameAz", cas, "group", description, "createdAt") FROM stdin;
\.


--
-- Data for Name: AdSlot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AdSlot" (id, key, label, mode, "campaignType", "externalCode", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AgroServiceRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AgroServiceRequest" (id, "userId", "serviceType", "farmLocation", "cropType", area, notes, "contactPhone", status, result, "resultFileUrl", "assignedTo", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AiSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiSettings" (id, "modelName", "systemPrompt", temperature, "updatedAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "userId", action, entity, "entityId", metadata, "oldValues", "newValues", "ipAddress", "createdAt") FROM stdin;
cmtupghbd0003bhddkaw0auqf	cmtun8f15003mum1hnjp96mhp	USER_LOGIN	User	cmtun8f15003mum1hnjp96mhp	{"details": "Successful login from IP: 5.191.122.71"}	\N	\N	\N	2026-09-09 23:04:02.473
cmtupivlw0003scvlzp293f7o	cmtun8f15003mum1hnjp96mhp	USER_LOGIN	User	cmtun8f15003mum1hnjp96mhp	{"details": "Successful login from IP: 109.94.96.57"}	\N	\N	\N	2026-09-09 23:05:54.308
\.


--
-- Data for Name: BlogPost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlogPost" (id, slug, "titleAz", "titleEn", "titleRu", "contentAz", "contentEn", "contentRu", "coverUrl", category, "authorId", "isPublished", "publishedAt", "viewCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Brand; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Brand" (id, name, slug, "logoUrl", country, website, description, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Bundle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Bundle" (id, title, description, "sellerId", "storeId", "discountType", "discountValue", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: BundleItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BundleItem" (id, "bundleId", "productId", quantity) FROM stdin;
\.


--
-- Data for Name: CalculatorSession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CalculatorSession" (id, "userId", "productId", area, "areaUnit", "useNorm", "waterNorm", applications, result, "createdAt") FROM stdin;
\.


--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Campaign" (id, title, type, status, "bannerUrl", "targetUrl", "storeId", "categoryId", region, "startDate", "endDate", budget, "costPerClick", impressions, clicks, conversions, spend, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Category" (id, slug, "nameAz", "nameEn", "nameRu", description, icon, "parentId", "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmtun8eld0000um1ho760xv8s	bitki-muhafize-vasiteleri	Bitki Mühafizə Vasitələri	Plant Protection	Средства защиты растений	\N	bug	\N	t	0	2026-09-09 22:01:46.465	2026-09-09 22:01:46.465
cmtun8elq0002um1hn0qu85ak	bitki-muhafize-vasiteleri-herbisidler	Herbisidlər	Herbisidlər	Herbisidlər	\N	\N	cmtun8eld0000um1ho760xv8s	t	1	2026-09-09 22:01:46.478	2026-09-09 22:01:46.478
cmtun8elx0004um1hdm42obp3	bitki-muhafize-vasiteleri-fungisidler	Fungisidlər	Fungisidlər	Fungisidlər	\N	\N	cmtun8eld0000um1ho760xv8s	t	2	2026-09-09 22:01:46.485	2026-09-09 22:01:46.485
cmtun8em10006um1hm2uis4na	bitki-muhafize-vasiteleri-insektisidler	İnsektisidlər	İnsektisidlər	İnsektisidlər	\N	\N	cmtun8eld0000um1ho760xv8s	t	3	2026-09-09 22:01:46.49	2026-09-09 22:01:46.49
cmtun8em50008um1ha5tctgoq	bitki-muhafize-vasiteleri-akarisidler	Akarisidlər	Akarisidlər	Akarisidlər	\N	\N	cmtun8eld0000um1ho760xv8s	t	4	2026-09-09 22:01:46.494	2026-09-09 22:01:46.494
cmtun8em9000aum1h9j2xn8wz	bitki-muhafize-vasiteleri-nematosidler	Nematosidlər	Nematosidlər	Nematosidlər	\N	\N	cmtun8eld0000um1ho760xv8s	t	5	2026-09-09 22:01:46.497	2026-09-09 22:01:46.497
cmtun8emd000cum1hmyq0qq7r	bitki-muhafize-vasiteleri-yapisdiricilar-adjuvant	Yapışdırıcılar (Adjuvant)	Yapışdırıcılar (Adjuvant)	Yapışdırıcılar (Adjuvant)	\N	\N	cmtun8eld0000um1ho760xv8s	t	6	2026-09-09 22:01:46.502	2026-09-09 22:01:46.502
cmtun8emi000eum1hvv703269	bitki-muhafize-vasiteleri-dezinfeksiya-vasiteleri	Dezinfeksiya vasitələri	Dezinfeksiya vasitələri	Dezinfeksiya vasitələri	\N	\N	cmtun8eld0000um1ho760xv8s	t	7	2026-09-09 22:01:46.507	2026-09-09 22:01:46.507
cmtun8emm000fum1hspcus4e7	gubreler	Gübrələr	Fertilizers	Удобрения	\N	sprout	\N	t	8	2026-09-09 22:01:46.511	2026-09-09 22:01:46.511
cmtun8emq000hum1h4lwx2sxq	gubreler-maye-gubreler	Maye gübrələr	Maye gübrələr	Maye gübrələr	\N	\N	cmtun8emm000fum1hspcus4e7	t	9	2026-09-09 22:01:46.515	2026-09-09 22:01:46.515
cmtun8emu000jum1hhv7shfrf	gubreler-qranul-gubreler	Qranul gübrələr	Qranul gübrələr	Qranul gübrələr	\N	\N	cmtun8emm000fum1hspcus4e7	t	10	2026-09-09 22:01:46.518	2026-09-09 22:01:46.518
cmtun8emy000lum1hqnur9u4k	gubreler-suda-hell-olan-gubreler	Suda həll olan gübrələr	Suda həll olan gübrələr	Suda həll olan gübrələr	\N	\N	cmtun8emm000fum1hspcus4e7	t	11	2026-09-09 22:01:46.522	2026-09-09 22:01:46.522
cmtun8en2000num1hw0jp0pm5	gubreler-yarpaq-gubreleri	Yarpaq gübrələri	Yarpaq gübrələri	Yarpaq gübrələri	\N	\N	cmtun8emm000fum1hspcus4e7	t	12	2026-09-09 22:01:46.526	2026-09-09 22:01:46.526
cmtun8en5000pum1hqev659dm	gubreler-damlama-gubreleri	Damlama gübrələri	Damlama gübrələri	Damlama gübrələri	\N	\N	cmtun8emm000fum1hspcus4e7	t	13	2026-09-09 22:01:46.53	2026-09-09 22:01:46.53
cmtun8en9000rum1hcfsf8c4z	gubreler-uzvi-gubreler	Üzvi gübrələr	Üzvi gübrələr	Üzvi gübrələr	\N	\N	cmtun8emm000fum1hspcus4e7	t	14	2026-09-09 22:01:46.534	2026-09-09 22:01:46.534
cmtun8end000tum1h3llmfp2a	gubreler-mikroelementler	Mikroelementlər	Mikroelementlər	Mikroelementlər	\N	\N	cmtun8emm000fum1hspcus4e7	t	15	2026-09-09 22:01:46.537	2026-09-09 22:01:46.537
cmtun8enh000vum1hxebvwo3z	gubreler-amin-tursulari	Amin turşuları	Amin turşuları	Amin turşuları	\N	\N	cmtun8emm000fum1hspcus4e7	t	16	2026-09-09 22:01:46.541	2026-09-09 22:01:46.541
cmtun8enk000xum1hmqm2dr0h	gubreler-humikfulvik-tursular	Humik/Fulvik turşular	Humik/Fulvik turşular	Humik/Fulvik turşular	\N	\N	cmtun8emm000fum1hspcus4e7	t	17	2026-09-09 22:01:46.545	2026-09-09 22:01:46.545
cmtun8eno000zum1h16g09pvf	gubreler-deniz-yosunu-mehsullari	Dəniz yosunu məhsulları	Dəniz yosunu məhsulları	Dəniz yosunu məhsulları	\N	\N	cmtun8emm000fum1hspcus4e7	t	18	2026-09-09 22:01:46.548	2026-09-09 22:01:46.548
cmtun8ens0010um1hb58r6plp	toxumlar	Toxumlar	Seeds	Семена	\N	leaf	\N	t	19	2026-09-09 22:01:46.552	2026-09-09 22:01:46.552
cmtun8enw0012um1hc2sieb7m	toxumlar-taxil	Taxıl	Taxıl	Taxıl	\N	\N	cmtun8ens0010um1hb58r6plp	t	20	2026-09-09 22:01:46.556	2026-09-09 22:01:46.556
cmtun8enz0014um1h7k179k91	toxumlar-pambiq	Pambıq	Pambıq	Pambıq	\N	\N	cmtun8ens0010um1hb58r6plp	t	21	2026-09-09 22:01:46.56	2026-09-09 22:01:46.56
cmtun8eo30016um1hizuiqvzd	toxumlar-qargidali	Qarğıdalı	Qarğıdalı	Qarğıdalı	\N	\N	cmtun8ens0010um1hb58r6plp	t	22	2026-09-09 22:01:46.563	2026-09-09 22:01:46.563
cmtun8eo70018um1hqob0e0pg	toxumlar-yonca	Yonca	Yonca	Yonca	\N	\N	cmtun8ens0010um1hb58r6plp	t	23	2026-09-09 22:01:46.568	2026-09-09 22:01:46.568
cmtun8eob001aum1h2bvx9gc9	toxumlar-terevez	Tərəvəz	Tərəvəz	Tərəvəz	\N	\N	cmtun8ens0010um1hb58r6plp	t	24	2026-09-09 22:01:46.571	2026-09-09 22:01:46.571
cmtun8eof001cum1hs4cfdqjf	toxumlar-meyve	Meyvə	Meyvə	Meyvə	\N	\N	cmtun8ens0010um1hb58r6plp	t	25	2026-09-09 22:01:46.576	2026-09-09 22:01:46.576
cmtun8eoj001eum1hhvemuacy	toxumlar-yem-bitkileri	Yem bitkiləri	Yem bitkiləri	Yem bitkiləri	\N	\N	cmtun8ens0010um1hb58r6plp	t	26	2026-09-09 22:01:46.58	2026-09-09 22:01:46.58
cmtun8eon001fum1hyqhnke8l	terkibine-gore	Tərkibinə görə	By Composition	По составу	\N	droplet	\N	t	27	2026-09-09 22:01:46.584	2026-09-09 22:01:46.584
cmtun8eor001hum1hp3p7d6x2	terkibine-gore-azot-n	Azot (N)	Azot (N)	Azot (N)	\N	\N	cmtun8eon001fum1hyqhnke8l	t	28	2026-09-09 22:01:46.587	2026-09-09 22:01:46.587
cmtun8eov001jum1h4h3rxg35	terkibine-gore-fosfor-p	Fosfor (P)	Fosfor (P)	Fosfor (P)	\N	\N	cmtun8eon001fum1hyqhnke8l	t	29	2026-09-09 22:01:46.592	2026-09-09 22:01:46.592
cmtun8eoz001lum1h5abzc7l9	terkibine-gore-kalium-k	Kalium (K)	Kalium (K)	Kalium (K)	\N	\N	cmtun8eon001fum1hyqhnke8l	t	30	2026-09-09 22:01:46.595	2026-09-09 22:01:46.595
cmtun8ep2001num1hk718xaq1	terkibine-gore-bor	Bor	Bor	Bor	\N	\N	cmtun8eon001fum1hyqhnke8l	t	31	2026-09-09 22:01:46.599	2026-09-09 22:01:46.599
cmtun8ep7001pum1hc2qrye6h	terkibine-gore-sink	Sink	Sink	Sink	\N	\N	cmtun8eon001fum1hyqhnke8l	t	32	2026-09-09 22:01:46.603	2026-09-09 22:01:46.603
cmtun8epa001rum1hfg8ofi23	terkibine-gore-demir	Dəmir	Dəmir	Dəmir	\N	\N	cmtun8eon001fum1hyqhnke8l	t	33	2026-09-09 22:01:46.607	2026-09-09 22:01:46.607
cmtun8epe001tum1hydmvty23	terkibine-gore-kalsium	Kalsium	Kalsium	Kalsium	\N	\N	cmtun8eon001fum1hyqhnke8l	t	34	2026-09-09 22:01:46.61	2026-09-09 22:01:46.61
cmtun8epi001uum1hmoqcgztb	texnika	Texnika	Equipment	Техника	\N	tractor	\N	t	35	2026-09-09 22:01:46.614	2026-09-09 22:01:46.614
cmtun8epl001wum1h9z7ixwsq	texnika-traktorlar	Traktorlar	Traktorlar	Traktorlar	\N	\N	cmtun8epi001uum1hmoqcgztb	t	36	2026-09-09 22:01:46.618	2026-09-09 22:01:46.618
cmtun8epp001yum1h1r1l0nlx	texnika-suvarma-sistemleri	Suvarma sistemləri	Suvarma sistemləri	Suvarma sistemləri	\N	\N	cmtun8epi001uum1hmoqcgztb	t	37	2026-09-09 22:01:46.622	2026-09-09 22:01:46.622
cmtun8ept0020um1h0l5r3quc	texnika-sprayerler	Sprayerlər	Sprayerlər	Sprayerlər	\N	\N	cmtun8epi001uum1hmoqcgztb	t	38	2026-09-09 22:01:46.625	2026-09-09 22:01:46.625
cmtun8epw0022um1hoeb69lpm	texnika-ekin-avadanliqlari	Əkin avadanlıqları	Əkin avadanlıqları	Əkin avadanlıqları	\N	\N	cmtun8epi001uum1hmoqcgztb	t	39	2026-09-09 22:01:46.629	2026-09-09 22:01:46.629
cmtun8eq00024um1hnfa43om2	texnika-yixim-texnikasi	Yıxım texnikası	Yıxım texnikası	Yıxım texnikası	\N	\N	cmtun8epi001uum1hmoqcgztb	t	40	2026-09-09 22:01:46.632	2026-09-09 22:01:46.632
cmtun8eq30025um1h1hi9lzsh	aqro-xidmetler	Aqro Xidmətlər	Agro Services	Агроуслуги	\N	grid	\N	t	41	2026-09-09 22:01:46.636	2026-09-09 22:01:46.636
cmtun8eq60027um1h1s8sy1e0	aqro-xidmetler-aqronom-xidmeti	Aqronom xidməti	Aqronom xidməti	Aqronom xidməti	\N	\N	cmtun8eq30025um1h1hi9lzsh	t	42	2026-09-09 22:01:46.639	2026-09-09 22:01:46.639
cmtun8eqa0029um1htezknp76	aqro-xidmetler-suvarma-xidmeti	Suvarma xidməti	Suvarma xidməti	Suvarma xidməti	\N	\N	cmtun8eq30025um1h1hi9lzsh	t	43	2026-09-09 22:01:46.642	2026-09-09 22:01:46.642
cmtun8eqe002bum1hlorkttx1	aqro-xidmetler-zererverici-ile-mubarize	Zərərverici ilə mübarizə	Zərərverici ilə mübarizə	Zərərverici ilə mübarizə	\N	\N	cmtun8eq30025um1h1hi9lzsh	t	44	2026-09-09 22:01:46.647	2026-09-09 22:01:46.647
cmtun8eqi002dum1h1mbkkph9	aqro-xidmetler-torpaq-analizi	Torpaq analizi	Torpaq analizi	Torpaq analizi	\N	\N	cmtun8eq30025um1h1hi9lzsh	t	45	2026-09-09 22:01:46.65	2026-09-09 22:01:46.65
cmtun8eql002fum1h4knpnira	aqro-xidmetler-ekin-isleri	Əkin işləri	Əkin işləri	Əkin işləri	\N	\N	cmtun8eq30025um1h1hi9lzsh	t	46	2026-09-09 22:01:46.654	2026-09-09 22:01:46.654
cmtun8eqp002gum1hg311empo	heyvandarliq	Heyvandarlıq	Livestock	Животноводство	\N	🐄	\N	t	47	2026-09-09 22:01:46.658	2026-09-09 22:01:46.658
cmtun8eqt002ium1hje9bm2fn	heyvandarliq-inek	İnək	İnək	İnək	\N	\N	cmtun8eqp002gum1hg311empo	t	48	2026-09-09 22:01:46.661	2026-09-09 22:01:46.661
cmtun8eqx002kum1ht0v6088k	heyvandarliq-buga	Buğa	Buğa	Buğa	\N	\N	cmtun8eqp002gum1hg311empo	t	49	2026-09-09 22:01:46.665	2026-09-09 22:01:46.665
cmtun8er0002mum1h4ugnh5h4	heyvandarliq-dana	Dana	Dana	Dana	\N	\N	cmtun8eqp002gum1hg311empo	t	50	2026-09-09 22:01:46.668	2026-09-09 22:01:46.668
cmtun8er3002oum1h6imwulni	heyvandarliq-qoyun	Qoyun	Qoyun	Qoyun	\N	\N	cmtun8eqp002gum1hg311empo	t	51	2026-09-09 22:01:46.672	2026-09-09 22:01:46.672
cmtun8er7002qum1hyuy51xkz	heyvandarliq-keci	Keçi	Keçi	Keçi	\N	\N	cmtun8eqp002gum1hg311empo	t	52	2026-09-09 22:01:46.675	2026-09-09 22:01:46.675
cmtun8era002sum1h9n6jawdd	heyvandarliq-camis	Camış	Camış	Camış	\N	\N	cmtun8eqp002gum1hg311empo	t	53	2026-09-09 22:01:46.679	2026-09-09 22:01:46.679
cmtun8ere002uum1h75npg10h	heyvandarliq-at	At	At	At	\N	\N	cmtun8eqp002gum1hg311empo	t	54	2026-09-09 22:01:46.682	2026-09-09 22:01:46.682
cmtun8erh002vum1ht3vipu5y	qusculuq	Quşçuluq	Poultry	Птицеводство	\N	🐔	\N	t	55	2026-09-09 22:01:46.685	2026-09-09 22:01:46.685
cmtun8erk002xum1h4xhoylpi	qusculuq-toyuq	Toyuq	Toyuq	Toyuq	\N	\N	cmtun8erh002vum1ht3vipu5y	t	56	2026-09-09 22:01:46.689	2026-09-09 22:01:46.689
cmtun8ero002zum1hhdwif5r0	qusculuq-hind-toyugu	Hind toyuğu	Hind toyuğu	Hind toyuğu	\N	\N	cmtun8erh002vum1ht3vipu5y	t	57	2026-09-09 22:01:46.692	2026-09-09 22:01:46.692
cmtun8err0031um1h4gttvr6q	qusculuq-ordek	Ördək	Ördək	Ördək	\N	\N	cmtun8erh002vum1ht3vipu5y	t	58	2026-09-09 22:01:46.696	2026-09-09 22:01:46.696
cmtun8erv0033um1hh3ifswdb	qusculuq-qaz	Qaz	Qaz	Qaz	\N	\N	cmtun8erh002vum1ht3vipu5y	t	59	2026-09-09 22:01:46.699	2026-09-09 22:01:46.699
cmtun8ery0034um1hobtaoqlp	aricilik	Arıçılık	Beekeeping	Пчеловодство	\N	🍯	\N	t	60	2026-09-09 22:01:46.703	2026-09-09 22:01:46.703
cmtun8es20036um1hottut0is	aricilik-bal	Bal	Bal	Bal	\N	\N	cmtun8ery0034um1hobtaoqlp	t	61	2026-09-09 22:01:46.706	2026-09-09 22:01:46.706
cmtun8es50038um1hjg2xumek	aricilik-ari-ailesi	Arı Ailəsi	Arı Ailəsi	Arı Ailəsi	\N	\N	cmtun8ery0034um1hobtaoqlp	t	62	2026-09-09 22:01:46.71	2026-09-09 22:01:46.71
cmtun8es9003aum1hc8grtheu	aricilik-ariciliq-avadanligi	Arıçılıq Avadanlığı	Arıçılıq Avadanlığı	Arıçılıq Avadanlığı	\N	\N	cmtun8ery0034um1hobtaoqlp	t	63	2026-09-09 22:01:46.713	2026-09-09 22:01:46.713
cmtun8esd003bum1hrbfum3j9	kampaniyalar	Kampaniyalar	Campaigns	Кампании	\N	tag	\N	t	64	2026-09-09 22:01:46.717	2026-09-09 22:01:46.717
cmtun8esg003dum1hwk6qo5bv	kampaniyalar-endirimler	Endirimlər	Endirimlər	Endirimlər	\N	\N	cmtun8esd003bum1hrbfum3j9	t	65	2026-09-09 22:01:46.72	2026-09-09 22:01:46.72
cmtun8esk003fum1haxawtwvw	kampaniyalar-yeni-mehsullar	Yeni məhsullar	Yeni məhsullar	Yeni məhsullar	\N	\N	cmtun8esd003bum1hrbfum3j9	t	66	2026-09-09 22:01:46.724	2026-09-09 22:01:46.724
cmtun8esn003hum1h2i1abvq6	kampaniyalar-movsumi-teklifler	Mövsümi təkliflər	Mövsümi təkliflər	Mövsümi təkliflər	\N	\N	cmtun8esd003bum1hrbfum3j9	t	67	2026-09-09 22:01:46.727	2026-09-09 22:01:46.727
cmtun8esr003jum1h4o9phowv	kampaniyalar-topdan-satis	Topdan satış	Topdan satış	Topdan satış	\N	\N	cmtun8esd003bum1hrbfum3j9	t	68	2026-09-09 22:01:46.731	2026-09-09 22:01:46.731
cmtun8esv003lum1hlxjkkr1c	kampaniyalar-resmi-distributor-mehsullari	Rəsmi distribütor məhsulları	Rəsmi distribütor məhsulları	Rəsmi distribütor məhsulları	\N	\N	cmtun8esd003bum1hrbfum3j9	t	69	2026-09-09 22:01:46.735	2026-09-09 22:01:46.735
\.


--
-- Data for Name: ClimateWarning; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ClimateWarning" (id, region, "warningType", severity, message, "startDate", "endDate", "isSmsSent", "isPushSent", "createdAt") FROM stdin;
\.


--
-- Data for Name: ComparisonSession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ComparisonSession" (id, "userId", "productIds", "createdAt") FROM stdin;
\.


--
-- Data for Name: ContactMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ContactMessage" (id, name, email, phone, subject, message, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Conversation" (id, "buyerId", "sellerId", "productId", "lastMessageAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Coupon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Coupon" (id, code, "discountType", "discountValue", "minOrderValue", "maxUses", "usedCount", "isActive", "startsAt", "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Crop; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Crop" (id, name, "nameAz", slug, image) FROM stdin;
\.


--
-- Data for Name: Disease; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Disease" (id, name, "nameAz", slug, images, "affectedCrops", symptoms, causes, prevention, treatment, "createdAt") FROM stdin;
\.


--
-- Data for Name: DynamicBlock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DynamicBlock" (id, page, type, props, "sortOrder", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EscrowTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EscrowTransaction" (id, "orderId", amount, status, "disputeReason", "resolvedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FarmerProfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FarmerProfile" (id, "userId", region, village, "totalArea", crops, greenhouse, garden, "irrigationType", "soilAnalysis", "previousProducts", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Favorite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Favorite" (id, "userId", "productId", "createdAt") FROM stdin;
\.


--
-- Data for Name: HomepageSlide; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HomepageSlide" (id, tag, title, subtitle, cta, href, bg, emoji, "imageUrl", "sortOrder", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: IncomingEmail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."IncomingEmail" (id, "fromEmail", "fromName", "toEmail", subject, "bodyText", "bodyHtml", "isRead", "isStarred", "isDeleted", "isReplied", "replyBody", "replySubject", "replySentAt", attachments, "messageId", "inReplyTo", "receivedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Listing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Listing" (id, "productId", tier, "startDate", "endDate", "autoRenew", views, clicks, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LogisticsTariff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LogisticsTariff" (id, "fromRegion", "toRegion", "basePrice", "pricePerKg", "estimatedDays") FROM stdin;
\.


--
-- Data for Name: LoyaltyLevel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LoyaltyLevel" (id, "levelName", "minPoints", "discountPercent", perks) FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "conversationId", "senderId", content, "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notification" (id, "userId", type, title, body, link, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Order" (id, "buyerId", subtotal, discount, commission, total, currency, "couponId", status, "shippingAddress", "shippingRegion", "shippingCity", "deliveryMethod", "deliveryCost", "deliveryPartnerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OrderItem" (id, "orderId", "productId", "sellerId", quantity, "unitPrice", "commissionRate") FROM stdin;
\.


--
-- Data for Name: PageLayout; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PageLayout" (id, "pageName", components, "themeColor", "isActive", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "expiresAt", used, "createdAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "orderId", provider, "providerRef", amount, currency, status, "rawResponse", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Permission" (id, action, description) FROM stdin;
\.


--
-- Data for Name: Pest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Pest" (id, name, "nameAz", slug, images, "affectedCrops", symptoms, lifecycle, prevention, "createdAt") FROM stdin;
\.


--
-- Data for Name: ProcurementRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProcurementRequest" (id, "userId", "productName", "categoryId", quantity, unit, budget, "deliveryLocation", description, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, slug, "titleAz", "titleEn", "titleRu", "descriptionAz", "descriptionEn", "descriptionRu", price, "discountedPrice", currency, stock, status, "categoryId", "sellerId", "guestName", "guestPhone", "storeId", region, city, lat, lng, tags, "isCorporate", "minOrderQty", "allowRetail", unit, "allowInstallment", "viewCount", "phoneViews", attributes, "rejectionReason", "preparativeForm", "useNorm", "waterVolume", "waitingPeriod", "maxApplications", "mixingCompatibility", "safetyInfo", "storageInfo", certificate, "labelPdfUrl", "instructionPdfUrl", "labelPdf", "instructionPdf", "videoUrl", barcode, "productCode", packaging, "wholesalePrice", "wholesaleMinQty", manufacturer, "brandId", "countryOfOrigin", "compareCount", "isOrganic", "createdAt", "updatedAt", "publishedAt", "expiresAt") FROM stdin;
cmtun8f22003qum1hrnbd58az	tarantula-1-litr	Tarantula (1 Litr)	Tarantula (1 Litr)	Tarantula (1 Litr)	İnsektisid. FermerMarket MMC rəsmi distribütor məhsulu.	İnsektisid. FermerMarket MMC rəsmi distribütor məhsulu.	İnsektisid. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8em10006um1hm2uis4na	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1 Litr	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.066	2026-09-09 22:01:47.066	\N	\N
cmtun8f2i003sum1hyl75nyv0	morkap-5-litr	Morkap (5 Litr)	Morkap (5 Litr)	Morkap (5 Litr)	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8elq0002um1hn0qu85ak	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5 Litr	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.082	2026-09-09 22:01:47.082	\N	\N
cmtun8f2n003uum1hwvd4xaxp	scout-500-qram	Scout (500 Qram)	Scout (500 Qram)	Scout (500 Qram)	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	Herbisid. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8elq0002um1hn0qu85ak	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	500 Qram	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.088	2026-09-09 22:01:47.088	\N	\N
cmtun8f2t003wum1h1hvleppr	azoxris	Azoxris	Azoxris	Azoxris	Fungisid. FermerMarket MMC rəsmi distribütor məhsulu.	Fungisid. FermerMarket MMC rəsmi distribütor məhsulu.	Fungisid. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8elx0004um1hdm42obp3	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.093	2026-09-09 22:01:47.093	\N	\N
cmtun8f2y003yum1hkoukcwwb	evroxim-kas-32	Evroxim KAS-32	Evroxim KAS-32	Evroxim KAS-32	Maye azot gübrəsi (KAS-32). Topdan: 2.80 AZN (min 10 ədəd).	Maye azot gübrəsi (KAS-32). Topdan: 2.80 AZN (min 10 ədəd).	Maye azot gübrəsi (KAS-32). Topdan: 2.80 AZN (min 10 ədəd).	3.50	\N	AZN	100	ACTIVE	cmtun8emq000hum1h4lwx2sxq	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2.80	10	\N	\N	\N	0	f	2026-09-09 22:01:47.098	2026-09-09 22:01:47.098	\N	\N
cmtun8f330040um1haz4a15pw	selectra-plus	Selectra Plus	Selectra Plus	Selectra Plus	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8eld0000um1ho760xv8s	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.104	2026-09-09 22:01:47.104	\N	\N
cmtun8f380042um1hzdfj9p4p	selectra-excellence	Selectra Excellence	Selectra Excellence	Selectra Excellence	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	Bitki mühafizə vasitəsi. FermerMarket MMC rəsmi distribütor məhsulu.	0.00	\N	AZN	100	ACTIVE	cmtun8eld0000um1ho760xv8s	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	f	\N	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	f	2026-09-09 22:01:47.109	2026-09-09 22:01:47.109	\N	\N
cmtun8f3d0044um1h2amgdk9z	seccozin-10-20-litr	SECCOZIN-10 (20 Litr)	SECCOZIN-10 (20 Litr)	SECCOZIN-10 (20 Litr)	Bitki mühafizə vasitəsi. Topdan minimum 5 ədəd.	Bitki mühafizə vasitəsi. Topdan minimum 5 ədəd.	Bitki mühafizə vasitəsi. Topdan minimum 5 ədəd.	0.00	\N	AZN	100	ACTIVE	cmtun8eld0000um1ho760xv8s	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	5	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	20 Litr	\N	5	\N	\N	\N	0	f	2026-09-09 22:01:47.113	2026-09-09 22:01:47.113	\N	\N
cmtun8f3i0046um1hbgc9ydhv	gladio-20-litr	GLADIO (20 Litr)	GLADIO (20 Litr)	GLADIO (20 Litr)	İnsektisid. Pərakəndə: 116 AZN, topdan: 106 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 116 AZN, topdan: 106 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 116 AZN, topdan: 106 AZN (min 5 ədəd).	116.00	\N	AZN	100	ACTIVE	cmtun8em10006um1hm2uis4na	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	5	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	20 Litr	106.00	5	\N	\N	\N	0	f	2026-09-09 22:01:47.118	2026-09-09 22:01:47.118	\N	\N
cmtun8f3x0048um1h1hsnipoe	pyri-tos-20-litr	PYRI-TOS (20 Litr)	PYRI-TOS (20 Litr)	PYRI-TOS (20 Litr)	İnsektisid. Pərakəndə: 140 AZN, topdan: 130 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 140 AZN, topdan: 130 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 140 AZN, topdan: 130 AZN (min 5 ədəd).	140.00	\N	AZN	100	ACTIVE	cmtun8em10006um1hm2uis4na	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	5	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	20 Litr	130.00	5	\N	\N	\N	0	f	2026-09-09 22:01:47.133	2026-09-09 22:01:47.133	\N	\N
cmtun8f42004aum1h1bhnbhvh	delta-20-litr	DELTA (20 Litr)	DELTA (20 Litr)	DELTA (20 Litr)	İnsektisid. Pərakəndə: 170 AZN, topdan: 160 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 170 AZN, topdan: 160 AZN (min 5 ədəd).	İnsektisid. Pərakəndə: 170 AZN, topdan: 160 AZN (min 5 ədəd).	170.00	\N	AZN	100	ACTIVE	cmtun8em10006um1hm2uis4na	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	5	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	20 Litr	160.00	5	\N	\N	\N	0	f	2026-09-09 22:01:47.138	2026-09-09 22:01:47.138	\N	\N
cmtun8f47004cum1h1l7tvmcx	hawk-5-sg	HAWK 5 SG	HAWK 5 SG	HAWK 5 SG	Herbisid. Pərakəndə: 25 AZN, topdan: 24 AZN (min 5 ədəd).	Herbisid. Pərakəndə: 25 AZN, topdan: 24 AZN (min 5 ədəd).	Herbisid. Pərakəndə: 25 AZN, topdan: 24 AZN (min 5 ədəd).	25.00	\N	AZN	100	ACTIVE	cmtun8elq0002um1hn0qu85ak	cmtun8f15003mum1hnjp96mhp	\N	\N	cmtun8f1i003oum1hy3c00x9v	\N	\N	\N	\N	{}	t	5	t	ədəd	f	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	24.00	5	\N	\N	\N	0	f	2026-09-09 22:01:47.143	2026-09-09 22:01:47.143	\N	\N
\.


--
-- Data for Name: ProductActiveIngredient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductActiveIngredient" ("productId", "activeIngredientId", concentration) FROM stdin;
\.


--
-- Data for Name: ProductCrop; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductCrop" ("productId", "cropId") FROM stdin;
\.


--
-- Data for Name: ProductDisease; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductDisease" ("productId", "diseaseId") FROM stdin;
\.


--
-- Data for Name: ProductImage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductImage" (id, "productId", url, "altText", "sortOrder") FROM stdin;
\.


--
-- Data for Name: ProductPest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductPest" ("productId", "pestId") FROM stdin;
\.


--
-- Data for Name: ProductRegistrationRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductRegistrationRequest" (id, "userId", "productName", "categoryId", description, "sellerInfo", price, images, documents, notes, status, "approvedBy", "approvedAt", "rejectionReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PushSubscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PushSubscription" (id, "userId", endpoint, p256dh, auth, "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt", revoked) FROM stdin;
cmtupgh8a0001bhdd41knivpq	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXR1bjhmMTUwMDNtdW0xaG5qcDk2bWhwIiwiaWF0IjoxNzg4OTk1MDQyLCJleHAiOjE3OTE1ODcwNDJ9.MlznsGGztUcP1LWC9A3P4Xths3ImtMlynKtOzKxpe0o	cmtun8f15003mum1hnjp96mhp	2026-10-09 23:04:02.361	2026-09-09 23:04:02.363	f
cmtupivip0001scvl3w1ni0qn	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXR1bjhmMTUwMDNtdW0xaG5qcDk2bWhwIiwiaWF0IjoxNzg4OTk1MTU0LCJleHAiOjE3OTE1ODcxNTR9.v9pGhnNGNfa0PMWv5VsFBNjzVZuykB87kf7RaSUOc1k	cmtun8f15003mum1hnjp96mhp	2026-10-09 23:05:54.193	2026-09-09 23:05:54.194	f
\.


--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Review" (id, "productId", "authorId", rating, comment, "isApproved", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RolePermission" (id, role, "permissionId") FROM stdin;
\.


--
-- Data for Name: SalesPoint; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SalesPoint" (id, "storeId", region, city, address, lat, lng, phone, "workHours", "isActive") FROM stdin;
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Setting" (id, key, value, category, "updatedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: SiteText; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SiteText" (id, key, "group", label, "valueAz", "valueEn", "valueRu", "isActive", "createdAt", "updatedAt") FROM stdin;
cmtun8f8z0000xmrjht5ls0xj	nav.products	navigation	Navigasiya — Məhsullar	Məhsullar	Products	Товары	t	2026-09-09 22:01:47.316	2026-09-09 22:01:47.316
cmtun8f9b0001xmrjz9r4smut	nav.categories	navigation	Navigasiya — Kateqoriyalar	Kateqoriyalar	Categories	Категории	t	2026-09-09 22:01:47.327	2026-09-09 22:01:47.327
cmtun8f9g0002xmrjgnrqio9x	nav.brands	navigation	Navigasiya — İstehsalçılar	İstehsalçılar	Brands	Производители	t	2026-09-09 22:01:47.332	2026-09-09 22:01:47.332
cmtun8f9l0003xmrjje5g2orz	nav.campaigns	navigation	Navigasiya — Kampaniyalar	Kampaniyalar	Campaigns	Кампании	t	2026-09-09 22:01:47.337	2026-09-09 22:01:47.337
cmtun8f9q0004xmrjo384shbb	nav.stores	navigation	Navigasiya — Mağazalar	Mağazalar	Stores	Магазины	t	2026-09-09 22:01:47.342	2026-09-09 22:01:47.342
cmtun8f9u0005xmrj2fqo1dkf	nav.agronom	navigation	Navigasiya — AI Aqronom	AI Aqronom	AI Agronomist	AI Агроном	t	2026-09-09 22:01:47.347	2026-09-09 22:01:47.347
cmtun8f9z0006xmrjn6e51bmc	nav.blog	navigation	Navigasiya — Bloq	Bloq	Blog	Блог	t	2026-09-09 22:01:47.352	2026-09-09 22:01:47.352
cmtun8fa40007xmrj7q4hkokk	nav.new_ad	navigation	Navigasiya — Yeni Elan Düyməsi	Yeni Elan	New Listing	Новое объявление	t	2026-09-09 22:01:47.356	2026-09-09 22:01:47.356
cmtun8fa90008xmrjyea0008x	nav.city	navigation	Navigasiya — Şəhər	Şəhər	City	Город	t	2026-09-09 22:01:47.361	2026-09-09 22:01:47.361
cmtun8fad0009xmrjl5qe85wy	nav.search_placeholder	navigation	Navigasiya — Axtarış placeholder	Məhsul, toxum, kimyəvi preparat və ya xəstəlik axtarın...	Search products, seeds, chemicals or diseases...	Поиск товаров, семян, химикатов или болезней...	t	2026-09-09 22:01:47.366	2026-09-09 22:01:47.366
cmtun8fai000axmrjboq0lqyr	nav.home	navigation	Aşağı Navigasiya — Əsas	Əsas	Home	Главная	t	2026-09-09 22:01:47.37	2026-09-09 22:01:47.37
cmtun8fam000bxmrj3gc2nlr5	nav.favorites	navigation	Aşağı Navigasiya — Seçilmiş	Seçilmiş	Favorites	Izbrannoe	t	2026-09-09 22:01:47.375	2026-09-09 22:01:47.375
cmtun8far000cxmrj4ijqqkfa	nav.messages	navigation	Aşağı Navigasiya — Mesajlar	Mesajlar	Messages	Сообщения	t	2026-09-09 22:01:47.38	2026-09-09 22:01:47.38
cmtun8faw000dxmrjruk6487u	nav.profile	navigation	Aşağı Navigasiya — Profil	Profil	Profile	Профиль	t	2026-09-09 22:01:47.384	2026-09-09 22:01:47.384
cmtun8fb1000exmrjiccl4f8b	nav.catalog	navigation	Aşağı Navigasiya — Kataloq	Kataloq	Catalog	Каталог	t	2026-09-09 22:01:47.389	2026-09-09 22:01:47.389
cmtun8fb5000fxmrj6idmawh3	nav.login	navigation	Aşağı Navigasiya — Giriş	Giriş	Login	Войти	t	2026-09-09 22:01:47.394	2026-09-09 22:01:47.394
cmtun8fba000gxmrjfradard2	nav.sell	navigation	Aşağı Navigasiya — Sat düyməsi	Sat	Sell	Продать	t	2026-09-09 22:01:47.398	2026-09-09 22:01:47.398
cmtun8fbe000hxmrj9923ryd2	home.hero.title	homepage	Ana Səhifə — Hero Başlıq	Sən də əkin, sat, qazan!	Plant, sell, earn!	Сажайте, продавайте, зарабатывайте!	t	2026-09-09 22:01:47.403	2026-09-09 22:01:47.403
cmtun8fbj000ixmrj8p2qxmjm	home.hero.subtitle	homepage	Ana Səhifə — Hero Alt Başlıq	Azərbaycanın ilk və ən böyük aqrar marketplace platforması	Azerbaijan's first and largest agricultural marketplace platform	Первая и крупнейшая аграрная маркетплейс платформа Азербайджана	t	2026-09-09 22:01:47.407	2026-09-09 22:01:47.407
cmtun8fbo000jxmrjmvovbd8u	home.search.placeholder	homepage	Ana Səhifə — Hero Axtarış Placeholder	Nə axtarırsınız? (məs: Pomidor toxumu)	What are you looking for? (e.g. Tomato seeds)	Что вы ищете? (например: Семена томатов)	t	2026-09-09 22:01:47.412	2026-09-09 22:01:47.412
cmtun8fbs000kxmrj8ml6vafa	home.search.button	homepage	Ana Səhifə — Hero Axtarış Düyməsi	Axtar	Search	Искать	t	2026-09-09 22:01:47.417	2026-09-09 22:01:47.417
cmtun8fbx000lxmrjcdrj656t	home.search.trending	homepage	Ana Səhifə — Trend Axtarışlar Başlığı	Trend Axtarışlar	Trending Searches	Популярные запросы	t	2026-09-09 22:01:47.422	2026-09-09 22:01:47.422
cmtun8fc1000mxmrje9kcipr9	home.stats.title	homepage	Ana Səhifə — Statistika Başlığı	Niyə FermerMarket?	Why FermerMarket?	Почему FermerMarket?	t	2026-09-09 22:01:47.426	2026-09-09 22:01:47.426
cmtun8fc6000nxmrjh7f81ant	home.stats.subtitle	homepage	Ana Səhifə — Statistika Alt Başlığı	Azərbaycanlı fermerlər bizi seçir	Azerbaijani farmers choose us	Азербайджанские фермеры выбирают нас	t	2026-09-09 22:01:47.43	2026-09-09 22:01:47.43
cmtun8fca000oxmrj9acy516d	home.stats.active_ads	homepage	Ana Səhifə — Statistika Aktiv Elan	Aktiv Elan	Active Ads	Активные объявления	t	2026-09-09 22:01:47.434	2026-09-09 22:01:47.434
cmtun8fce000pxmrj368irktr	home.stats.farmers	homepage	Ana Səhifə — Statistika Fermer	Fermer	Farmers	Фермеры	t	2026-09-09 22:01:47.439	2026-09-09 22:01:47.439
cmtun8fcj000qxmrjxrb0g3iu	home.stats.stores	homepage	Ana Səhifə — Statistika Mağaza	Mağaza	Stores	Магазины	t	2026-09-09 22:01:47.443	2026-09-09 22:01:47.443
cmtun8fcn000rxmrjhuc6hlgu	home.stats.satisfied	homepage	Ana Səhifə — Statistika Məmnun İstifadəçi	Məmnun İstifadəçi	Satisfied Users	Довольные пользователи	t	2026-09-09 22:01:47.448	2026-09-09 22:01:47.448
cmtun8fcs000sxmrjb6k2b0hn	home.agronom.tag	homepage	Ana Səhifə — AI Aqronom Tag	AI ilə işləyir	Powered by AI	Работает на ИИ	t	2026-09-09 22:01:47.453	2026-09-09 22:01:47.453
cmtun8fcx000txmrjvj0z60tl	home.agronom.title	homepage	Ana Səhifə — AI Aqronom Başlıq	AI Aqronom	AI Agronomist	AI Агроном	t	2026-09-09 22:01:47.457	2026-09-09 22:01:47.457
cmtun8fd1000uxmrjtnes1eep	home.agronom.description	homepage	Ana Səhifə — AI Aqronom Təsviri	Bitkinizdə xəstəlik var? Şəkil göndərin, AI analiz etsin. Torpaq, məhsul, iqlim haqqında sual verin.	Has your plant got a disease? Send a photo for AI analysis.	Болезнь у растения? Отправьте фото для ИИ анализа.	t	2026-09-09 22:01:47.462	2026-09-09 22:01:47.462
cmtun8fd6000vxmrjytlw5t6j	home.agronom.btn_photo	homepage	Ana Səhifə — AI Aqronom Şəkil Düyməsi	Şəkil Göndər	Send Photo	Отправить фото	t	2026-09-09 22:01:47.466	2026-09-09 22:01:47.466
cmtun8fdb000wxmrjfatkxw4p	home.agronom.btn_ask	homepage	Ana Səhifə — AI Aqronom Sual Düyməsi	Sual Ver	Ask Question	Задать вопрос	t	2026-09-09 22:01:47.471	2026-09-09 22:01:47.471
cmtun8fdf000xxmrjrf2n99k8	home.categories.title	homepage	Ana Səhifə — Kateqoriyalar Bölməsi Başlığı	Kateqoriyalar	Categories	Категории	t	2026-09-09 22:01:47.476	2026-09-09 22:01:47.476
cmtun8fdj000yxmrjgoexok9l	home.premium.title	homepage	Ana Səhifə — Premium Elanlar Başlığı	Premium Elanlar	Premium Ads	Премиум объявления	t	2026-09-09 22:01:47.48	2026-09-09 22:01:47.48
cmtun8fdo000zxmrjqcxxt2xu	home.latest.title	homepage	Ana Səhifə — Yeni Elanlar Başlığı	Yeni Elanlar	New Listings	Новые объявления	t	2026-09-09 22:01:47.484	2026-09-09 22:01:47.484
cmtun8fds0010xmrjl9369v43	home.bundles.title	homepage	Ana Səhifə — Bağlamalar Başlığı	Bağlamalar	Bundles	Пакеты	t	2026-09-09 22:01:47.489	2026-09-09 22:01:47.489
cmtun8fdx0011xmrj1tj839h2	home.blog.title	homepage	Ana Səhifə — Bloq Bölməsi Başlığı	Fermer Məsləhətləri	Farmer Tips	Советы фермеру	t	2026-09-09 22:01:47.493	2026-09-09 22:01:47.493
cmtun8fe10012xmrjx7ovi86e	home.blog.subtitle	homepage	Ana Səhifə — Bloq Alt Başlıq	Kənd təsərrüfatı haqqında faydalı məqalələr	Useful articles about agriculture	Полезные статьи о сельском хозяйстве	t	2026-09-09 22:01:47.497	2026-09-09 22:01:47.497
cmtun8fe50013xmrj8g09piqn	home.blog.read_more	homepage	Ana Səhifə — Bloq Hamısına Bax Düyməsi	Hamısı	View All	Все	t	2026-09-09 22:01:47.501	2026-09-09 22:01:47.501
cmtun8fe90014xmrjdr5h6ucw	footer.about_title	footer	Footer — Haqqında Başlıq	FermerMarket haqqında	About FermerMarket	О FermerMarket	t	2026-09-09 22:01:47.506	2026-09-09 22:01:47.506
cmtun8fee0015xmrjt7ng1cv6	footer.about_desc	footer	Footer — Haqqında Mətn	Azərbaycanın ilk və ən böyük aqrar marketplace platforması. Kənd təsərrüfatı məhsullarının onlayn satışı və alışı.	Azerbaijan's first agricultural marketplace.	Первый аграрный маркетплейс Азербайджана.	t	2026-09-09 22:01:47.51	2026-09-09 22:01:47.51
cmtun8fei0016xmrjn5upclii	footer.col_products	footer	Footer — Məhsullar Sütun Başlığı	Məhsullar	Products	Товары	t	2026-09-09 22:01:47.514	2026-09-09 22:01:47.514
cmtun8fen0017xmrjimgy79mt	footer.col_company	footer	Footer — Şirkət Sütun Başlığı	Şirkət	Company	Компания	t	2026-09-09 22:01:47.519	2026-09-09 22:01:47.519
cmtun8fer0018xmrjp0r655d1	footer.col_contact	footer	Footer — Əlaqə Sütun Başlığı	Əlaqə	Contact	Контакты	t	2026-09-09 22:01:47.524	2026-09-09 22:01:47.524
cmtun8fev0019xmrjzisadzsc	footer.copyright	footer	Footer — Müəllif Hüquqları Mətni	Bütün hüquqlar qorunur.	All rights reserved.	Все права защищены.	t	2026-09-09 22:01:47.528	2026-09-09 22:01:47.528
cmtun8ff0001axmrjmhefl6uo	products.page_title	products	Məhsullar Səhifəsi — Başlıq	Bütün Elanlar	All Listings	Все объявления	t	2026-09-09 22:01:47.532	2026-09-09 22:01:47.532
cmtun8ff4001bxmrjt3et6plt	products.search_results	products	Məhsullar Səhifəsi — Axtarış Nəticələri Mətni	üzrə axtarış nəticələri	search results for	результаты поиска по	t	2026-09-09 22:01:47.537	2026-09-09 22:01:47.537
cmtun8ff9001cxmrjyiirjpz0	products.empty_title	products	Məhsullar Səhifəsi — Boş Nəticə Başlığı	Heç bir elan tapılmadı	No listings found	Объявления не найдены	t	2026-09-09 22:01:47.541	2026-09-09 22:01:47.541
cmtun8ffd001dxmrjx2j167vw	products.empty_desc	products	Məhsullar Səhifəsi — Boş Nəticə Təsviri	Axtarış parametrlərini dəyişərək yenidən cəhd edin.	Try changing your search parameters.	Попробуйте изменить параметры поиска.	t	2026-09-09 22:01:47.545	2026-09-09 22:01:47.545
cmtun8ffh001exmrjiwu1zjqj	products.filter_title	products	Məhsullar Səhifəsi — Filtr Başlığı	Filtrlər	Filters	Фильтры	t	2026-09-09 22:01:47.55	2026-09-09 22:01:47.55
cmtun8ffm001fxmrjlvm2shcq	stores.page_title	stores	Mağazalar Səhifəsi — Başlıq	Rəsmi Mağazalar	Official Stores	Официальные магазины	t	2026-09-09 22:01:47.554	2026-09-09 22:01:47.554
cmtun8ffq001gxmrjj7z2vuo5	stores.subtitle	stores	Mağazalar Səhifəsi — Alt Başlıq	Kənd təsərrüfatı texnikası, toxum, gübrə və aqro-kimya mağazaları	Agricultural equipment, seed, fertilizer and agro-chemical stores	Магазины сельхозтехники, семян и удобрений	t	2026-09-09 22:01:47.558	2026-09-09 22:01:47.558
cmtun8ffv001hxmrjmuci3nma	blog.page_title	blog	Bloq Səhifəsi — Başlıq	Fermer Məsləhətləri və Aqro Bloq	Farmer Advice & Agro Blog	Советы фермеру и Агро блог	t	2026-09-09 22:01:47.563	2026-09-09 22:01:47.563
cmtun8ffz001ixmrjykpjtjjy	blog.subtitle	blog	Bloq Səhifəsi — Alt Başlıq	Kənd təsərrüfatı, əkinçilik, heyvandarlıq və yeni texnologiyalar haqqında faydalı məqalələr	Useful articles about agriculture, farming and livestock	Полезные статьи о сельском хозяйстве и животноводстве	t	2026-09-09 22:01:47.568	2026-09-09 22:01:47.568
\.


--
-- Data for Name: Store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Store" (id, "ownerId", name, slug, description, "logoUrl", "coverUrl", address, lat, lng, whatsapp, phone, website, "isVerified", "isActive", "installmentEnabled", "installmentWhatsapp", email, facebook, instagram, tiktok, linkedin, youtube, telegram, "workingHours", "deliveryRegions", "taxInfo", "bankName", "bankAccount", iban, "supportEmail", "supportPhone", "primaryColor", "secondaryColor", "themeMode", "followerCount", "storeViewCount", "totalSales", "createdAt", "updatedAt") FROM stdin;
cmtun8f1i003oum1hy3c00x9v	cmtun8f15003mum1hnjp96mhp	FermerMarket MMC	fermermarket-mmc	Kənd təsərrüfatı məhsulları — bitki mühafizə vasitələri, gübrələr və aqro xidmətlər. Rəsmi distribütor.	\N	\N	Azərbaycan, Bakı	\N	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	\N	\N	\N	\N	\N	\N	#16a34a	\N	light	0	0	0	2026-09-09 22:01:47.047	2026-09-09 22:01:47.047
\.


--
-- Data for Name: StoreFollow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StoreFollow" (id, "storeId", "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: StoreSubscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StoreSubscription" (id, "storeId", plan, "planId", status, "startedAt", "renewsAt") FROM stdin;
\.


--
-- Data for Name: SubscriptionPlan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SubscriptionPlan" (id, name, price, currency, "durationDays", "maxListings", "freeVipListings", "customSubdomain", "isActive") FROM stdin;
\.


--
-- Data for Name: SystemText; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemText" (id, key, "valueAz", "valueEn", "valueRu", module, "updatedAt") FROM stdin;
\.


--
-- Data for Name: TieredPrice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TieredPrice" (id, "productId", "tierType", "minQuantity", price, "regionCode", "isActive") FROM stdin;
\.


--
-- Data for Name: Translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Translation" (id, "entityType", "entityId", field, locale, value) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, phone, username, "passwordHash", "fullName", role, status, locale, "emailVerified", "phoneVerified", "isBanned", "avgRating", "reviewCount", "deliveryRating", "onTimeDeliveryRate", "createdAt", "updatedAt", "storeId") FROM stdin;
cmtun8f15003mum1hnjp96mhp	info@fermermarket.az	\N	elgun	$2a$12$BfPZ97Sq01g1lswyMaFfSeHst.BS54sStqzGcGCm9Bpm.Z3GC17pK	Elgün Gasimov	SUPER_ADMIN	ACTIVE	AZ	t	f	f	0	0	0	0	2026-09-09 22:01:47.034	2026-09-09 22:01:47.034	\N
\.


--
-- Data for Name: UserModule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserModule" (id, "userId", module, "grantedBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: Wallet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Wallet" (id, "userId", balance, coins, currency, "createdAt", "updatedAt") FROM stdin;
cmtupghs60005bhddn5qq85sw	cmtun8f15003mum1hnjp96mhp	0.00	0.00	AZN	2026-09-09 23:04:03.078	2026-09-09 23:04:03.078
\.


--
-- Data for Name: WalletTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WalletTransaction" (id, "walletId", type, status, amount, "orderId", description, "loyaltyPointsEarned", "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f5729ba4-7519-498c-8b76-de2f44c4994d	11ae8d2c95a0d2ab26d41cdeaf347ac015b1a8c6943718eaef712407f151e9e8	2026-09-09 22:01:46.20361+00	20260824223457_fermermarket2508	\N	\N	2026-09-09 22:01:45.788338+00	1
c8a104fe-f748-4533-87dd-26a9278eef76	d21c12171f2810123b1f8fcd3dd1bb26c7d078815506e6ed39d2461f3c67c5ae	2026-09-09 22:01:46.233044+00	20260826131634_add_service_requests	\N	\N	2026-09-09 22:01:46.208584+00	1
\.


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (id);


--
-- Name: jwks jwks_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.jwks
    ADD CONSTRAINT jwks_pkey PRIMARY KEY (id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_key; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_slug_key UNIQUE (slug);


--
-- Name: project_config project_config_endpoint_id_key; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_endpoint_id_key UNIQUE (endpoint_id);


--
-- Name: project_config project_config_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_key; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_token_key UNIQUE (token);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: AIAgroRule AIAgroRule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AIAgroRule"
    ADD CONSTRAINT "AIAgroRule_pkey" PRIMARY KEY (id);


--
-- Name: ActiveIngredient ActiveIngredient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ActiveIngredient"
    ADD CONSTRAINT "ActiveIngredient_pkey" PRIMARY KEY (id);


--
-- Name: AdSlot AdSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdSlot"
    ADD CONSTRAINT "AdSlot_pkey" PRIMARY KEY (id);


--
-- Name: AgroServiceRequest AgroServiceRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgroServiceRequest"
    ADD CONSTRAINT "AgroServiceRequest_pkey" PRIMARY KEY (id);


--
-- Name: AiSettings AiSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiSettings"
    ADD CONSTRAINT "AiSettings_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BlogPost BlogPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_pkey" PRIMARY KEY (id);


--
-- Name: Brand Brand_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Brand"
    ADD CONSTRAINT "Brand_pkey" PRIMARY KEY (id);


--
-- Name: BundleItem BundleItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BundleItem"
    ADD CONSTRAINT "BundleItem_pkey" PRIMARY KEY (id);


--
-- Name: Bundle Bundle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bundle"
    ADD CONSTRAINT "Bundle_pkey" PRIMARY KEY (id);


--
-- Name: CalculatorSession CalculatorSession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CalculatorSession"
    ADD CONSTRAINT "CalculatorSession_pkey" PRIMARY KEY (id);


--
-- Name: Campaign Campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: ClimateWarning ClimateWarning_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ClimateWarning"
    ADD CONSTRAINT "ClimateWarning_pkey" PRIMARY KEY (id);


--
-- Name: ComparisonSession ComparisonSession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ComparisonSession"
    ADD CONSTRAINT "ComparisonSession_pkey" PRIMARY KEY (id);


--
-- Name: ContactMessage ContactMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ContactMessage"
    ADD CONSTRAINT "ContactMessage_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: Coupon Coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Coupon"
    ADD CONSTRAINT "Coupon_pkey" PRIMARY KEY (id);


--
-- Name: Crop Crop_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Crop"
    ADD CONSTRAINT "Crop_pkey" PRIMARY KEY (id);


--
-- Name: Disease Disease_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Disease"
    ADD CONSTRAINT "Disease_pkey" PRIMARY KEY (id);


--
-- Name: DynamicBlock DynamicBlock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DynamicBlock"
    ADD CONSTRAINT "DynamicBlock_pkey" PRIMARY KEY (id);


--
-- Name: EscrowTransaction EscrowTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EscrowTransaction"
    ADD CONSTRAINT "EscrowTransaction_pkey" PRIMARY KEY (id);


--
-- Name: FarmerProfile FarmerProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FarmerProfile"
    ADD CONSTRAINT "FarmerProfile_pkey" PRIMARY KEY (id);


--
-- Name: Favorite Favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_pkey" PRIMARY KEY (id);


--
-- Name: HomepageSlide HomepageSlide_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomepageSlide"
    ADD CONSTRAINT "HomepageSlide_pkey" PRIMARY KEY (id);


--
-- Name: IncomingEmail IncomingEmail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."IncomingEmail"
    ADD CONSTRAINT "IncomingEmail_pkey" PRIMARY KEY (id);


--
-- Name: Listing Listing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Listing"
    ADD CONSTRAINT "Listing_pkey" PRIMARY KEY (id);


--
-- Name: LogisticsTariff LogisticsTariff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogisticsTariff"
    ADD CONSTRAINT "LogisticsTariff_pkey" PRIMARY KEY (id);


--
-- Name: LoyaltyLevel LoyaltyLevel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LoyaltyLevel"
    ADD CONSTRAINT "LoyaltyLevel_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PageLayout PageLayout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PageLayout"
    ADD CONSTRAINT "PageLayout_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: Pest Pest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Pest"
    ADD CONSTRAINT "Pest_pkey" PRIMARY KEY (id);


--
-- Name: ProcurementRequest ProcurementRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProcurementRequest"
    ADD CONSTRAINT "ProcurementRequest_pkey" PRIMARY KEY (id);


--
-- Name: ProductActiveIngredient ProductActiveIngredient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductActiveIngredient"
    ADD CONSTRAINT "ProductActiveIngredient_pkey" PRIMARY KEY ("productId", "activeIngredientId");


--
-- Name: ProductCrop ProductCrop_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCrop"
    ADD CONSTRAINT "ProductCrop_pkey" PRIMARY KEY ("productId", "cropId");


--
-- Name: ProductDisease ProductDisease_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductDisease"
    ADD CONSTRAINT "ProductDisease_pkey" PRIMARY KEY ("productId", "diseaseId");


--
-- Name: ProductImage ProductImage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductImage"
    ADD CONSTRAINT "ProductImage_pkey" PRIMARY KEY (id);


--
-- Name: ProductPest ProductPest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductPest"
    ADD CONSTRAINT "ProductPest_pkey" PRIMARY KEY ("productId", "pestId");


--
-- Name: ProductRegistrationRequest ProductRegistrationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductRegistrationRequest"
    ADD CONSTRAINT "ProductRegistrationRequest_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: PushSubscription PushSubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PushSubscription"
    ADD CONSTRAINT "PushSubscription_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: SalesPoint SalesPoint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SalesPoint"
    ADD CONSTRAINT "SalesPoint_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: SiteText SiteText_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SiteText"
    ADD CONSTRAINT "SiteText_pkey" PRIMARY KEY (id);


--
-- Name: StoreFollow StoreFollow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreFollow"
    ADD CONSTRAINT "StoreFollow_pkey" PRIMARY KEY (id);


--
-- Name: StoreSubscription StoreSubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreSubscription"
    ADD CONSTRAINT "StoreSubscription_pkey" PRIMARY KEY (id);


--
-- Name: Store Store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Store"
    ADD CONSTRAINT "Store_pkey" PRIMARY KEY (id);


--
-- Name: SubscriptionPlan SubscriptionPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SubscriptionPlan"
    ADD CONSTRAINT "SubscriptionPlan_pkey" PRIMARY KEY (id);


--
-- Name: SystemText SystemText_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemText"
    ADD CONSTRAINT "SystemText_pkey" PRIMARY KEY (id);


--
-- Name: TieredPrice TieredPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TieredPrice"
    ADD CONSTRAINT "TieredPrice_pkey" PRIMARY KEY (id);


--
-- Name: Translation Translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Translation"
    ADD CONSTRAINT "Translation_pkey" PRIMARY KEY (id);


--
-- Name: UserModule UserModule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserModule"
    ADD CONSTRAINT "UserModule_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WalletTransaction WalletTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Wallet Wallet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Wallet"
    ADD CONSTRAINT "Wallet_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: account_userId_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX "account_userId_idx" ON neon_auth.account USING btree ("userId");


--
-- Name: invitation_email_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX invitation_email_idx ON neon_auth.invitation USING btree (email);


--
-- Name: invitation_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX "invitation_organizationId_idx" ON neon_auth.invitation USING btree ("organizationId");


--
-- Name: member_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX "member_organizationId_idx" ON neon_auth.member USING btree ("organizationId");


--
-- Name: member_userId_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX "member_userId_idx" ON neon_auth.member USING btree ("userId");


--
-- Name: organization_slug_uidx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE UNIQUE INDEX organization_slug_uidx ON neon_auth.organization USING btree (slug);


--
-- Name: session_userId_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX "session_userId_idx" ON neon_auth.session USING btree ("userId");


--
-- Name: verification_identifier_idx; Type: INDEX; Schema: neon_auth; Owner: -
--

CREATE INDEX verification_identifier_idx ON neon_auth.verification USING btree (identifier);


--
-- Name: ActiveIngredient_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ActiveIngredient_name_key" ON public."ActiveIngredient" USING btree (name);


--
-- Name: AdSlot_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdSlot_key_key" ON public."AdSlot" USING btree (key);


--
-- Name: AgroServiceRequest_serviceType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AgroServiceRequest_serviceType_idx" ON public."AgroServiceRequest" USING btree ("serviceType");


--
-- Name: AgroServiceRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AgroServiceRequest_status_idx" ON public."AgroServiceRequest" USING btree (status);


--
-- Name: AgroServiceRequest_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AgroServiceRequest_userId_idx" ON public."AgroServiceRequest" USING btree ("userId");


--
-- Name: AuditLog_entity_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_entity_entityId_idx" ON public."AuditLog" USING btree (entity, "entityId");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: BlogPost_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BlogPost_category_idx" ON public."BlogPost" USING btree (category);


--
-- Name: BlogPost_isPublished_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BlogPost_isPublished_idx" ON public."BlogPost" USING btree ("isPublished");


--
-- Name: BlogPost_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BlogPost_slug_key" ON public."BlogPost" USING btree (slug);


--
-- Name: Brand_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Brand_isActive_idx" ON public."Brand" USING btree ("isActive");


--
-- Name: Brand_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Brand_name_key" ON public."Brand" USING btree (name);


--
-- Name: Brand_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Brand_slug_key" ON public."Brand" USING btree (slug);


--
-- Name: BundleItem_bundleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BundleItem_bundleId_idx" ON public."BundleItem" USING btree ("bundleId");


--
-- Name: BundleItem_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BundleItem_productId_idx" ON public."BundleItem" USING btree ("productId");


--
-- Name: Bundle_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Bundle_isActive_idx" ON public."Bundle" USING btree ("isActive");


--
-- Name: Bundle_sellerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Bundle_sellerId_idx" ON public."Bundle" USING btree ("sellerId");


--
-- Name: Campaign_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Campaign_startDate_endDate_idx" ON public."Campaign" USING btree ("startDate", "endDate");


--
-- Name: Campaign_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Campaign_status_idx" ON public."Campaign" USING btree (status);


--
-- Name: Campaign_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Campaign_type_idx" ON public."Campaign" USING btree (type);


--
-- Name: Category_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Category_isActive_idx" ON public."Category" USING btree ("isActive");


--
-- Name: Category_parentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Category_parentId_idx" ON public."Category" USING btree ("parentId");


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: Conversation_buyerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Conversation_buyerId_idx" ON public."Conversation" USING btree ("buyerId");


--
-- Name: Conversation_buyerId_sellerId_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Conversation_buyerId_sellerId_productId_key" ON public."Conversation" USING btree ("buyerId", "sellerId", "productId");


--
-- Name: Conversation_sellerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Conversation_sellerId_idx" ON public."Conversation" USING btree ("sellerId");


--
-- Name: Coupon_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Coupon_code_key" ON public."Coupon" USING btree (code);


--
-- Name: Coupon_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Coupon_isActive_idx" ON public."Coupon" USING btree ("isActive");


--
-- Name: Crop_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Crop_slug_key" ON public."Crop" USING btree (slug);


--
-- Name: Disease_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Disease_slug_key" ON public."Disease" USING btree (slug);


--
-- Name: DynamicBlock_page_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DynamicBlock_page_isActive_idx" ON public."DynamicBlock" USING btree (page, "isActive");


--
-- Name: DynamicBlock_sortOrder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DynamicBlock_sortOrder_idx" ON public."DynamicBlock" USING btree ("sortOrder");


--
-- Name: EscrowTransaction_orderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "EscrowTransaction_orderId_key" ON public."EscrowTransaction" USING btree ("orderId");


--
-- Name: FarmerProfile_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "FarmerProfile_userId_key" ON public."FarmerProfile" USING btree ("userId");


--
-- Name: Favorite_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Favorite_productId_idx" ON public."Favorite" USING btree ("productId");


--
-- Name: Favorite_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Favorite_userId_idx" ON public."Favorite" USING btree ("userId");


--
-- Name: Favorite_userId_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Favorite_userId_productId_key" ON public."Favorite" USING btree ("userId", "productId");


--
-- Name: IncomingEmail_isRead_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IncomingEmail_isRead_idx" ON public."IncomingEmail" USING btree ("isRead");


--
-- Name: IncomingEmail_receivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IncomingEmail_receivedAt_idx" ON public."IncomingEmail" USING btree ("receivedAt");


--
-- Name: IncomingEmail_toEmail_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IncomingEmail_toEmail_idx" ON public."IncomingEmail" USING btree ("toEmail");


--
-- Name: Listing_endDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Listing_endDate_idx" ON public."Listing" USING btree ("endDate");


--
-- Name: Listing_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Listing_productId_key" ON public."Listing" USING btree ("productId");


--
-- Name: Listing_tier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Listing_tier_idx" ON public."Listing" USING btree (tier);


--
-- Name: LoyaltyLevel_levelName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "LoyaltyLevel_levelName_key" ON public."LoyaltyLevel" USING btree ("levelName");


--
-- Name: Message_conversationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_conversationId_idx" ON public."Message" USING btree ("conversationId");


--
-- Name: Message_senderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_senderId_idx" ON public."Message" USING btree ("senderId");


--
-- Name: Notification_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_userId_createdAt_idx" ON public."Notification" USING btree ("userId", "createdAt" DESC);


--
-- Name: Notification_userId_isRead_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_userId_isRead_idx" ON public."Notification" USING btree ("userId", "isRead");


--
-- Name: OrderItem_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "OrderItem_orderId_idx" ON public."OrderItem" USING btree ("orderId");


--
-- Name: OrderItem_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "OrderItem_productId_idx" ON public."OrderItem" USING btree ("productId");


--
-- Name: OrderItem_sellerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "OrderItem_sellerId_idx" ON public."OrderItem" USING btree ("sellerId");


--
-- Name: Order_buyerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Order_buyerId_idx" ON public."Order" USING btree ("buyerId");


--
-- Name: Order_deliveryPartnerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Order_deliveryPartnerId_idx" ON public."Order" USING btree ("deliveryPartnerId");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: PageLayout_pageName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PageLayout_pageName_key" ON public."PageLayout" USING btree ("pageName");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: Payment_orderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Payment_orderId_key" ON public."Payment" USING btree ("orderId");


--
-- Name: Payment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_status_idx" ON public."Payment" USING btree (status);


--
-- Name: Permission_action_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Permission_action_key" ON public."Permission" USING btree (action);


--
-- Name: Pest_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Pest_slug_key" ON public."Pest" USING btree (slug);


--
-- Name: ProductActiveIngredient_activeIngredientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductActiveIngredient_activeIngredientId_idx" ON public."ProductActiveIngredient" USING btree ("activeIngredientId");


--
-- Name: ProductActiveIngredient_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductActiveIngredient_productId_idx" ON public."ProductActiveIngredient" USING btree ("productId");


--
-- Name: ProductCrop_cropId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCrop_cropId_idx" ON public."ProductCrop" USING btree ("cropId");


--
-- Name: ProductCrop_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCrop_productId_idx" ON public."ProductCrop" USING btree ("productId");


--
-- Name: ProductDisease_diseaseId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductDisease_diseaseId_idx" ON public."ProductDisease" USING btree ("diseaseId");


--
-- Name: ProductDisease_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductDisease_productId_idx" ON public."ProductDisease" USING btree ("productId");


--
-- Name: ProductImage_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductImage_productId_idx" ON public."ProductImage" USING btree ("productId");


--
-- Name: ProductPest_pestId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductPest_pestId_idx" ON public."ProductPest" USING btree ("pestId");


--
-- Name: ProductPest_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductPest_productId_idx" ON public."ProductPest" USING btree ("productId");


--
-- Name: Product_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_categoryId_idx" ON public."Product" USING btree ("categoryId");


--
-- Name: Product_price_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_price_idx" ON public."Product" USING btree (price);


--
-- Name: Product_sellerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_sellerId_idx" ON public."Product" USING btree ("sellerId");


--
-- Name: Product_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_slug_key" ON public."Product" USING btree (slug);


--
-- Name: Product_status_categoryId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_status_categoryId_createdAt_idx" ON public."Product" USING btree (status, "categoryId", "createdAt" DESC);


--
-- Name: Product_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_status_createdAt_idx" ON public."Product" USING btree (status, "createdAt" DESC);


--
-- Name: Product_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_status_idx" ON public."Product" USING btree (status);


--
-- Name: Product_storeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_storeId_idx" ON public."Product" USING btree ("storeId");


--
-- Name: PushSubscription_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PushSubscription_endpoint_key" ON public."PushSubscription" USING btree (endpoint);


--
-- Name: PushSubscription_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PushSubscription_userId_idx" ON public."PushSubscription" USING btree ("userId");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RefreshToken_userId_idx" ON public."RefreshToken" USING btree ("userId");


--
-- Name: Review_authorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Review_authorId_idx" ON public."Review" USING btree ("authorId");


--
-- Name: Review_isApproved_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Review_isApproved_productId_idx" ON public."Review" USING btree ("isApproved", "productId");


--
-- Name: Review_productId_authorId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Review_productId_authorId_key" ON public."Review" USING btree ("productId", "authorId");


--
-- Name: Review_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Review_productId_idx" ON public."Review" USING btree ("productId");


--
-- Name: RolePermission_role_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RolePermission_role_permissionId_key" ON public."RolePermission" USING btree (role, "permissionId");


--
-- Name: SalesPoint_storeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SalesPoint_storeId_idx" ON public."SalesPoint" USING btree ("storeId");


--
-- Name: Setting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Setting_key_key" ON public."Setting" USING btree (key);


--
-- Name: SiteText_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SiteText_key_key" ON public."SiteText" USING btree (key);


--
-- Name: StoreFollow_storeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StoreFollow_storeId_idx" ON public."StoreFollow" USING btree ("storeId");


--
-- Name: StoreFollow_storeId_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "StoreFollow_storeId_userId_key" ON public."StoreFollow" USING btree ("storeId", "userId");


--
-- Name: StoreFollow_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StoreFollow_userId_idx" ON public."StoreFollow" USING btree ("userId");


--
-- Name: StoreSubscription_planId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StoreSubscription_planId_idx" ON public."StoreSubscription" USING btree ("planId");


--
-- Name: StoreSubscription_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StoreSubscription_status_idx" ON public."StoreSubscription" USING btree (status);


--
-- Name: StoreSubscription_storeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "StoreSubscription_storeId_key" ON public."StoreSubscription" USING btree ("storeId");


--
-- Name: Store_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Store_isActive_idx" ON public."Store" USING btree ("isActive");


--
-- Name: Store_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Store_slug_key" ON public."Store" USING btree (slug);


--
-- Name: SubscriptionPlan_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SubscriptionPlan_name_key" ON public."SubscriptionPlan" USING btree (name);


--
-- Name: SystemText_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemText_key_key" ON public."SystemText" USING btree (key);


--
-- Name: TieredPrice_productId_tierType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "TieredPrice_productId_tierType_idx" ON public."TieredPrice" USING btree ("productId", "tierType");


--
-- Name: Translation_entityType_entityId_field_locale_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Translation_entityType_entityId_field_locale_key" ON public."Translation" USING btree ("entityType", "entityId", field, locale);


--
-- Name: Translation_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Translation_entityType_entityId_idx" ON public."Translation" USING btree ("entityType", "entityId");


--
-- Name: UserModule_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "UserModule_userId_idx" ON public."UserModule" USING btree ("userId");


--
-- Name: UserModule_userId_module_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserModule_userId_module_key" ON public."UserModule" USING btree ("userId", module);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: User_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_status_idx" ON public."User" USING btree (status);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: WalletTransaction_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WalletTransaction_type_idx" ON public."WalletTransaction" USING btree (type);


--
-- Name: WalletTransaction_walletId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WalletTransaction_walletId_idx" ON public."WalletTransaction" USING btree ("walletId");


--
-- Name: Wallet_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Wallet_userId_key" ON public."Wallet" USING btree ("userId");


--
-- Name: account account_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT "account_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_inviterId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_inviterId_fkey" FOREIGN KEY ("inviterId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: session session_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: -
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT "session_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: AgroServiceRequest AgroServiceRequest_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgroServiceRequest"
    ADD CONSTRAINT "AgroServiceRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BlogPost BlogPost_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BundleItem BundleItem_bundleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BundleItem"
    ADD CONSTRAINT "BundleItem_bundleId_fkey" FOREIGN KEY ("bundleId") REFERENCES public."Bundle"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BundleItem BundleItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BundleItem"
    ADD CONSTRAINT "BundleItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Bundle Bundle_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Bundle"
    ADD CONSTRAINT "Bundle_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Campaign Campaign_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaign Campaign_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Category Category_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversation Conversation_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Conversation Conversation_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversation Conversation_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FarmerProfile FarmerProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FarmerProfile"
    ADD CONSTRAINT "FarmerProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorite Favorite_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorite Favorite_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Listing Listing_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Listing"
    ADD CONSTRAINT "Listing_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_couponId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_couponId_fkey" FOREIGN KEY ("couponId") REFERENCES public."Coupon"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_deliveryPartnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_deliveryPartnerId_fkey" FOREIGN KEY ("deliveryPartnerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProcurementRequest ProcurementRequest_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProcurementRequest"
    ADD CONSTRAINT "ProcurementRequest_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProcurementRequest ProcurementRequest_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProcurementRequest"
    ADD CONSTRAINT "ProcurementRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductActiveIngredient ProductActiveIngredient_activeIngredientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductActiveIngredient"
    ADD CONSTRAINT "ProductActiveIngredient_activeIngredientId_fkey" FOREIGN KEY ("activeIngredientId") REFERENCES public."ActiveIngredient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductActiveIngredient ProductActiveIngredient_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductActiveIngredient"
    ADD CONSTRAINT "ProductActiveIngredient_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCrop ProductCrop_cropId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCrop"
    ADD CONSTRAINT "ProductCrop_cropId_fkey" FOREIGN KEY ("cropId") REFERENCES public."Crop"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCrop ProductCrop_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCrop"
    ADD CONSTRAINT "ProductCrop_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductDisease ProductDisease_diseaseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductDisease"
    ADD CONSTRAINT "ProductDisease_diseaseId_fkey" FOREIGN KEY ("diseaseId") REFERENCES public."Disease"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductDisease ProductDisease_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductDisease"
    ADD CONSTRAINT "ProductDisease_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductImage ProductImage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductImage"
    ADD CONSTRAINT "ProductImage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductPest ProductPest_pestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductPest"
    ADD CONSTRAINT "ProductPest_pestId_fkey" FOREIGN KEY ("pestId") REFERENCES public."Pest"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductPest ProductPest_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductPest"
    ADD CONSTRAINT "ProductPest_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductRegistrationRequest ProductRegistrationRequest_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductRegistrationRequest"
    ADD CONSTRAINT "ProductRegistrationRequest_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductRegistrationRequest ProductRegistrationRequest_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductRegistrationRequest"
    ADD CONSTRAINT "ProductRegistrationRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_brandId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_brandId_fkey" FOREIGN KEY ("brandId") REFERENCES public."Brand"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PushSubscription PushSubscription_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PushSubscription"
    ADD CONSTRAINT "PushSubscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Review Review_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SalesPoint SalesPoint_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SalesPoint"
    ADD CONSTRAINT "SalesPoint_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StoreFollow StoreFollow_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreFollow"
    ADD CONSTRAINT "StoreFollow_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StoreFollow StoreFollow_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreFollow"
    ADD CONSTRAINT "StoreFollow_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StoreSubscription StoreSubscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreSubscription"
    ADD CONSTRAINT "StoreSubscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."SubscriptionPlan"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StoreSubscription StoreSubscription_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StoreSubscription"
    ADD CONSTRAINT "StoreSubscription_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Store Store_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Store"
    ADD CONSTRAINT "Store_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TieredPrice TieredPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TieredPrice"
    ADD CONSTRAINT "TieredPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserModule UserModule_grantedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserModule"
    ADD CONSTRAINT "UserModule_grantedBy_fkey" FOREIGN KEY ("grantedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserModule UserModule_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserModule"
    ADD CONSTRAINT "UserModule_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public."Store"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WalletTransaction WalletTransaction_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."Wallet"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Wallet Wallet_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Wallet"
    ADD CONSTRAINT "Wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 8pRtIyNtXgSA72dnvV0ko9DefVYnYIE6KoRRSOdebVIhEXXj8X8GDGlHi91N8vB

